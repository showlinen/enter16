By default Odoo downloads PDF reports. This module opens PDF reports in a new browser tab instead of downloading.
