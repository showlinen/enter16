`2.0.0`
-------

- **Improvement:** rename `post_channel_message` to  `message_post`
- **Improvement:** always show Discuss sidebar category, i.e. even when there are no chats

`1.2.0`
-------

- **Improvement:** allow extra keyword arguments for post_channel_message

`1.1.1`
-------

- **Fix:** public channels were not shown
- **Fix:** access error while leaving the channel

`1.1.0`
-------

- **New:** access all channels by clicking channel group title
- **New:** hide channel by clicking a [X] button

`1.0.0`
-------

- **Init version**
