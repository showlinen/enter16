Activity Management v16
======================
Activity Management

Installation
============
	- www.odoo.com/documentation/16.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Megha v15 @ cybrosys, Contact: odoo@cybrosys.com
               Amaya Aravind EV v16 @ cybrosys, Contact: odoo@cybrosys.com
